import os
import numpy as np
import math
import random
import cryptorandom


### CONSISTENT SAMPLING ###
# Assign ticket numbers
## NOTE: ADD TIE BREAKING RULE
def assign_random_number(cvr_list):
    n = len(cvr_list)
    # generate uniform random numbers
    seed = np.random.randint(0, 10**10, dtype=np.int64)
    sha_hash = SHA256(seed)
    random_numbers = sha_hash.random(n)
    # append random number to ballots
    sorted_list = cvr_list
    for i in range(n):
        sorted_list[i].append(random_numbers[i])
    # sort CVRs by random numbers
    sorted_list.sort(key = lambda x: x[7])
    return sorted_list
    # return CVRs -- NOTE: does these operations automatically so not sure if necessary
    #return cvr_list.sort(key = lambda x: x[7])


def get_ballots_threshold(sorted_cvr_list, sample_size_dict, sampled_CVRs = []):
    # get list of contests to consider from threshold dict
    contest_list = list(sample_size_dict.keys())
    # get list of ticket numbers for the cvr list
    ticket_number_list = [item[7] for item in sorted_cvr_list]
    # loop through each contest
    for contest in contest_list:
        # return true if contest on ballot
        contest_on_ballot = [contest in item[0] for item in sorted_cvr_list]
        contest_indices = np.where(contest_on_ballot)[0]
        # get ballots where contest on ballot and still need to sample more ballots and append to sampled_CVRs if not already included
        sampled_ballots = 0
        for i in contest_indices:
            if cvr_list[i] not in sampled_CVRs and sampled_ballots < sample_size_dict[contest]:
                sampled_CVRs.append(cvr_list[i])
            sampled_ballots += 1
    # NOTE: SHOULD WE ADD ALSO WHICH CONTEST IT'S BEING SAMPLED FOR -- PART OF THE DICT???
    # return CVRs to sample
    return sampled_CVRs
